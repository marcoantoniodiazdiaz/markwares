# Socket-Server

## Marco Antonio Diaz Diaz

### Servidor de Sockets para el Chat de Servicio Automotriz Diaz.

Levantar servidor:

```
nodemon dist/
node dist/
```
